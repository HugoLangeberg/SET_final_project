# Import game class
from game import *

# Create a new game. Default state: "start" and the game is running
game = Game()
# Run the game
game.run()
